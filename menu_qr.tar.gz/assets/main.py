import asyncio
import csv
from datetime import datetime
import random
import pygame

pygame.init()
ANCHO, ALTO = 520, 780
pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Menú QR Restaurante - Comensal / Admin")
reloj = pygame.time.Clock()

fuente = pygame.font.Font(None, 24)
fuente_titulo = pygame.font.Font(None, 30)
fuente_estado = pygame.font.Font(None, 23)
fuente_chica = pygame.font.Font(None, 21)

CLAVE_ADMIN = "admin"
TURNOS = ["Mañana", "Tarde", "Noche"]
MESAS = [f"Mesa #{i:02d}" for i in range(1, 7)]
MESEROS = ["Mesero 1", "Mesero 2", "Mesero 3"]
NOTAS_RAPIDAS = ["Normal", "Sin ají", "Sin cebolla", "Bien cocido"]
PROPINAS_OPCIONES = [0.0, 1.0, 2.0]

CATALOGO_PLATOS = {
    "Lomo saltado": {"local": 7.00, "llevar": 7.50, "stock": 10, "pausado": False, "estilo": "saltado"},
    "Ají de gallina": {"local": 6.50, "llevar": 7.00, "stock": 10, "pausado": False, "estilo": "crema"},
    "Arroz con pollo": {"local": 6.00, "llevar": 6.50, "stock": 12, "pausado": False, "estilo": "arroz"},
    "Ceviche clásico": {"local": 8.00, "llevar": 8.50, "stock": 8, "pausado": False, "estilo": "marino"},
    "Tallarines verdes": {"local": 6.50, "llevar": 7.00, "stock": 10, "pausado": False, "estilo": "pasta"},
    "Pollo a la brasa": {"local": 9.00, "llevar": 9.50, "stock": 10, "pausado": False, "estilo": "asado"},
    "Causa limeña": {"local": 5.50, "llevar": 6.00, "stock": 9, "pausado": False, "estilo": "frio"},
    "Anticuchos": {"local": 7.50, "llevar": 8.00, "stock": 8, "pausado": False, "estilo": "asado"},
    "Seco de res": {"local": 7.50, "llevar": 8.00, "stock": 8, "pausado": False, "estilo": "guiso"},
    "Carapulcra": {"local": 6.50, "llevar": 7.00, "stock": 8, "pausado": False, "estilo": "guiso"},
    "Arroz chaufa": {"local": 6.50, "llevar": 7.00, "stock": 12, "pausado": False, "estilo": "arroz"},
    "Tallarín saltado": {"local": 6.50, "llevar": 7.00, "stock": 10, "pausado": False, "estilo": "saltado"},
    "Caldo de gallina": {"local": 7.00, "llevar": 7.50, "stock": 10, "pausado": False, "estilo": "sopa"},
    "Sopa criolla": {"local": 6.50, "llevar": 7.00, "stock": 9, "pausado": False, "estilo": "sopa"},
    "Papa a la huancaína": {"local": 5.00, "llevar": 5.50, "stock": 10, "pausado": False, "estilo": "crema"},
    "Rocoto relleno": {"local": 7.50, "llevar": 8.00, "stock": 7, "pausado": False, "estilo": "horno"},
    "Adobo arequipeño": {"local": 8.00, "llevar": 8.50, "stock": 7, "pausado": False, "estilo": "guiso"},
    "Chanfainita": {"local": 5.50, "llevar": 6.00, "stock": 9, "pausado": False, "estilo": "guiso"},
    "Escabeche de pollo": {"local": 6.50, "llevar": 7.00, "stock": 8, "pausado": False, "estilo": "guiso"},
    "Pescado a lo macho": {"local": 9.50, "llevar": 10.00, "stock": 6, "pausado": False, "estilo": "marino"},
    "Jalea mixta": {"local": 9.00, "llevar": 9.50, "stock": 7, "pausado": False, "estilo": "marino"},
    "Chicharrón de pollo": {"local": 7.00, "llevar": 7.50, "stock": 10, "pausado": False, "estilo": "asado"},
    "Milanesa de pollo": {"local": 7.00, "llevar": 7.50, "stock": 9, "pausado": False, "estilo": "asado"},
    "Bistec a lo pobre": {"local": 8.50, "llevar": 9.00, "stock": 8, "pausado": False, "estilo": "saltado"},
    "Salchipapa especial": {"local": 6.00, "llevar": 6.50, "stock": 12, "pausado": False, "estilo": "asado"},
    "Choclo con queso": {"local": 4.00, "llevar": 4.50, "stock": 10, "pausado": False, "estilo": "frio"},
    "Tamal criollo": {"local": 4.50, "llevar": 5.00, "stock": 10, "pausado": False, "estilo": "horno"},
    "Mazamorra morada": {"local": 3.50, "llevar": 4.00, "stock": 12, "pausado": False, "estilo": "dulce"},
    "Arroz con leche": {"local": 3.50, "llevar": 4.00, "stock": 12, "pausado": False, "estilo": "dulce"},
    "Leche asada": {"local": 4.50, "llevar": 5.00, "stock": 8, "pausado": False, "estilo": "dulce"},
    "Chicha morada": {"local": 3.00, "llevar": 3.50, "stock": 15, "pausado": False, "estilo": "bebida"},
    "Limonada frozen": {"local": 3.50, "llevar": 4.00, "stock": 15, "pausado": False, "estilo": "bebida"},
}


def rotar_turnos():
    todos = list(CATALOGO_PLATOS.keys())
    random.shuffle(todos)
    return {
        "Mañana": todos[0:5],
        "Tarde": todos[5:10],
        "Noche": todos[10:15],
    }


def dibujar_icono_plato(plato, rect_img):
    pygame.draw.rect(pantalla, (255, 255, 255), rect_img, border_radius=8)
    pygame.draw.rect(pantalla, (175, 175, 175), rect_img, 1, border_radius=8)

    cx, cy = rect_img.center
    estilo = CATALOGO_PLATOS.get(plato, {}).get("estilo", "saltado")

    if estilo == "marino":
        pygame.draw.circle(pantalla, (95, 185, 225), (cx, cy + 2), 12)
        pygame.draw.polygon(pantalla, (240, 145, 95), [(cx - 7, cy + 2), (cx + 5, cy - 4), (cx + 5, cy + 8)])
    elif estilo == "arroz":
        pygame.draw.ellipse(pantalla, (245, 235, 175), (cx - 12, cy - 4, 24, 15))
        pygame.draw.circle(pantalla, (75, 175, 85), (cx - 4, cy + 2), 3)
        pygame.draw.circle(pantalla, (220, 70, 60), (cx + 4, cy + 1), 3)
    elif estilo == "crema":
        pygame.draw.circle(pantalla, (245, 195, 55), (cx, cy + 2), 12)
        pygame.draw.circle(pantalla, (250, 245, 220), (cx - 3, cy - 2), 3)
    elif estilo == "pasta":
        pygame.draw.circle(pantalla, (95, 185, 90), (cx, cy + 2), 12)
        pygame.draw.arc(pantalla, (235, 200, 75), (cx - 9, cy - 4, 18, 12), 0.2, 2.9, 3)
    elif estilo == "asado":
        pygame.draw.ellipse(pantalla, (165, 85, 40), (cx - 12, cy - 6, 24, 16))
        pygame.draw.circle(pantalla, (235, 220, 195), (cx + 10, cy - 5), 4)
    elif estilo == "sopa":
        pygame.draw.circle(pantalla, (230, 170, 65), (cx, cy + 2), 12)
        pygame.draw.line(pantalla, (150, 150, 150), (cx - 5, cy - 14), (cx - 5, cy - 9), 2)
        pygame.draw.line(pantalla, (150, 150, 150), (cx + 4, cy - 15), (cx + 4, cy - 9), 2)
    elif estilo == "dulce":
        pygame.draw.circle(pantalla, (140, 70, 130), (cx, cy + 2), 12)
        pygame.draw.circle(pantalla, (250, 235, 140), (cx, cy + 1), 4)
    elif estilo == "bebida":
        pygame.draw.rect(pantalla, (125, 75, 145), (cx - 8, cy - 9, 16, 20), border_radius=3)
        pygame.draw.line(pantalla, (220, 235, 245), (cx + 2, cy - 15), (cx + 7, cy - 5), 2)
    elif estilo == "frio":
        pygame.draw.rect(pantalla, (245, 205, 65), (cx - 10, cy - 7, 20, 16), border_radius=4)
        pygame.draw.circle(pantalla, (220, 65, 65), (cx, cy + 1), 4)
    elif estilo == "horno":
        pygame.draw.rect(pantalla, (205, 115, 55), (cx - 11, cy - 7, 22, 16), border_radius=5)
    else:
        pygame.draw.circle(pantalla, (185, 95, 55), (cx, cy + 2), 12)
        pygame.draw.circle(pantalla, (80, 175, 80), (cx + 5, cy - 3), 4)


menu_por_turno = rotar_turnos()
turno_actual = "Mañana"
indice_mesa = 3
modo = "comensal"
propina_actual = 0.0

esperando_clave_admin = False
clave_escrita = ""

titulo = ""
estado = ""
estado_color = (0, 135, 0)
botones = []

carrito = []
ordenes_pendientes = []
ordenes_entregadas = []
ultimo_recibo = None


def mesa_actual():
    return MESAS[indice_mesa]


def subtotal_carrito():
    return sum(item["precio"] for item in carrito)


def total_carrito():
    return subtotal_carrito() + propina_actual


def registrar_orden_csv(orden):
    try:
        with open("pedidos_restaurante.csv", "a", newline="", encoding="utf-8") as f:
            resumen = " / ".join(
                f"{x['plato']} [{x['modalidad']}, {x['nota']}] S/ {x['precio']:.2f}"
                for x in orden["items"]
            )
            csv.writer(f).writerow([
                orden["fecha"],
                orden["id"],
                orden["mesa"],
                orden["turno"],
                resumen,
                f"{orden['subtotal']:.2f}",
                f"{orden['propina']:.2f}",
                f"{orden['total']:.2f}",
            ])
    except Exception:
        pass


class Boton:
    def __init__(self, texto, accion, color=(190, 215, 255), activo=True, plato_img=None):
        self.texto = texto
        self.accion = accion
        self.color = color
        self.activo = activo
        self.plato_img = plato_img
        self.rect = pygame.Rect(0, 0, 445, 48 if plato_img else 38)
        self.escala = 1.0

    def actualizar(self, mouse):
        if not self.activo:
            self.escala = 1.0
            return
        objetivo = 1.04 if self.rect.collidepoint(mouse) else 1.0
        self.escala += (objetivo - self.escala) * 0.25

    def dibujar(self):
        ancho = int(self.rect.width * self.escala)
        alto = int(self.rect.height * self.escala)
        caja = pygame.Rect(0, 0, ancho, alto)
        caja.center = self.rect.center

        if not self.activo:
            color = (215, 215, 215)
            color_texto = (135, 135, 135)
        else:
            brillo = int(22 * (self.escala - 1.0) / 0.04)
            color = tuple(min(255, c + brillo) for c in self.color)
            color_texto = (25, 25, 25)

        pygame.draw.rect(pantalla, color, caja, border_radius=8)
        pygame.draw.rect(pantalla, (65, 65, 65), caja, 2, border_radius=8)

        if self.plato_img is not None:
            tam_img = max(28, alto - 10)
            rect_img = pygame.Rect(caja.left + 8, caja.centery - tam_img // 2, tam_img, tam_img)
            dibujar_icono_plato(self.plato_img, rect_img)
            img = fuente.render(self.texto, True, color_texto)
            pantalla.blit(img, img.get_rect(midleft=(rect_img.right + 10, caja.centery)))
        else:
            img = fuente.render(self.texto, True, color_texto)
            pantalla.blit(img, img.get_rect(center=caja.center))


def lineas_ajustadas(texto, fuente_, ancho_max):
    lineas = []
    for parrafo in texto.split("\n"):
        actual = ""
        for palabra in parrafo.split(" "):
            prueba = (actual + " " + palabra).strip()
            if fuente_.size(prueba)[0] <= ancho_max:
                actual = prueba
            else:
                lineas.append(actual)
                actual = palabra
        lineas.append(actual)
    return lineas


def dibujar_texto(texto, fuente_, color, y):
    for linea in lineas_ajustadas(texto, fuente_, ANCHO - 34):
        if linea:
            img = fuente_.render(linea, True, color)
            pantalla.blit(img, img.get_rect(centerx=ANCHO // 2, y=y))
        y += fuente_.get_height() + 2


def poner_pantalla(nuevo_titulo, lista_botones, y_inicio=105, separacion=44):
    global titulo, botones
    titulo = nuevo_titulo
    botones = lista_botones
    y_actual = y_inicio
    for b in botones:
        b.rect.centerx = ANCHO // 2
        b.rect.y = y_actual
        y_actual += max(separacion, b.rect.height + 6)


def abrir_login_admin():
    global esperando_clave_admin, clave_escrita, estado, estado_color
    esperando_clave_admin = True
    clave_escrita = ""
    estado = "Escribe 'admin' con el teclado y pulsa Enter."
    estado_color = (140, 70, 0)
    render_login_admin()


def render_login_admin():
    oculto = "*" * len(clave_escrita) if clave_escrita else "(vacío)"
    lista = [
        Boton("Entrar", validar_clave_admin, (180, 235, 190)),
        Boton("Borrar clave", borrar_clave_admin, (255, 225, 180)),
        Boton("< Cancelar", cancelar_login_admin, (215, 215, 215)),
    ]
    poner_pantalla(f"Acceso Admin Restaurante\nClave: {oculto}", lista, y_inicio=185, separacion=52)


def borrar_clave_admin():
    global clave_escrita
    clave_escrita = ""
    render_login_admin()


def cancelar_login_admin():
    global esperando_clave_admin, clave_escrita, estado, estado_color
    esperando_clave_admin = False
    clave_escrita = ""
    estado = "Ingreso cancelado."
    estado_color = (100, 100, 100)
    menu_principal(limpiar=False)


def validar_clave_admin():
    global modo, esperando_clave_admin, clave_escrita, estado, estado_color
    if clave_escrita.strip().lower() == CLAVE_ADMIN:
        modo = "admin"
        esperando_clave_admin = False
        clave_escrita = ""
        estado = "Modo Admin activo: gestiona platos, mesas y meseros."
        estado_color = (140, 70, 0)
        menu_principal(limpiar=False)
    else:
        clave_escrita = ""
        estado = "Clave incorrecta. Escribe 'admin'."
        estado_color = (200, 0, 0)
        render_login_admin()


def volver_a_comensal():
    global modo, estado, estado_color
    modo = "comensal"
    estado = f"Menú QR activo en {mesa_actual()}."
    estado_color = (0, 135, 0)
    menu_principal(limpiar=False)


def cambiar_turno(nuevo_turno):
    global turno_actual, estado, estado_color
    turno_actual = nuevo_turno
    estado = f"Turno cambiado a {turno_actual} (5 platos disponibles)."
    estado_color = (30, 95, 165)
    menu_principal(limpiar=False)


def rotar_mesa():
    global indice_mesa, estado, estado_color
    indice_mesa = (indice_mesa + 1) % len(MESAS)
    estado = f"Escaneo actualizado: {mesa_actual()}."
    estado_color = (30, 95, 165)
    menu_principal(limpiar=False)


def rotar_platos_turno():
    global menu_por_turno, estado, estado_color
    menu_por_turno = rotar_turnos()
    estado = "Rotación aleatoria aplicada a Mañana, Tarde y Noche."
    estado_color = (140, 70, 0)
    menu_principal(limpiar=False)


def menu_principal(limpiar=True):
    global estado, esperando_clave_admin
    esperando_clave_admin = False
    if limpiar:
        estado = ""

    lista = []
    if modo == "comensal":
        for plato in menu_por_turno[turno_actual]:
            datos = CATALOGO_PLATOS[plato]
            disp = (not datos["pausado"]) and datos["stock"] > 0
            if datos["pausado"]:
                etiqueta = "PAUSADO"
            elif datos["stock"] <= 0:
                etiqueta = "AGOTADO"
            else:
                etiqueta = f"St:{datos['stock']}"

            texto = f"{plato} | Loc S/ {datos['local']:.2f} - Llev S/ {datos['llevar']:.2f} ({etiqueta})"
            lista.append(
                Boton(
                    texto,
                    lambda p=plato: elegir_modalidad(p),
                    color=(252, 252, 255) if disp else (225, 225, 225),
                    activo=disp,
                    plato_img=plato,
                )
            )

        siguiente_turno = TURNOS[(TURNOS.index(turno_actual) + 1) % len(TURNOS)]
        lista.append(Boton(f"Cambiar mesa ({mesa_actual()})", rotar_mesa, (215, 232, 255)))
        lista.append(
            Boton(
                f"Turno: {turno_actual} (Cambiar a {siguiente_turno})",
                lambda t=siguiente_turno: cambiar_turno(t),
                (205, 225, 250),
            )
        )
        lista.append(
            Boton(
                f"Ver pedido ({len(carrito)}) - S/ {total_carrito():.2f}",
                pantalla_pedido,
                (190, 240, 200),
            )
        )
        if ultimo_recibo is not None:
            lista.append(
                Boton(
                    f"Ver recibo ({ultimo_recibo['id']})",
                    lambda: pantalla_recibo(ultimo_recibo),
                    (235, 225, 185),
                )
            )
        lista.append(Boton("Admin / Cocina", abrir_login_admin, (255, 220, 170)))
        poner_pantalla(f"QR {mesa_actual()}  |  Turno: {turno_actual}", lista, y_inicio=66, separacion=48)
    else:
        lista.append(
            Boton(
                f"Órdenes para enviar ({len(ordenes_pendientes)})",
                pantalla_despacho_meseros,
                (255, 225, 175),
            )
        )
        lista.append(
            Boton(
                f"Entregadas / Recibos ({len(ordenes_entregadas)})",
                pantalla_entregadas,
                (195, 235, 205),
            )
        )
        for plato in menu_por_turno[turno_actual]:
            datos = CATALOGO_PLATOS[plato]
            marca = " [PAUSA]" if datos["pausado"] else ""
            lista.append(
                Boton(
                    f"{plato}{marca} | L S/ {datos['local']:.2f} | Ll S/ {datos['llevar']:.2f} | St:{datos['stock']}",
                    lambda p=plato: panel_admin_plato(p),
                    color=(255, 240, 205) if not datos["pausado"] else (235, 215, 215),
                    plato_img=plato,
                )
            )
        lista.append(Boton("Rotar 5 platos por turno", rotar_platos_turno, (215, 230, 255)))
        lista.append(Boton("Volver a Menú QR", volver_a_comensal, (185, 225, 255)))
        poner_pantalla(f"[ADMIN] {mesa_actual()} | Turno {turno_actual}", lista, y_inicio=66, separacion=48)


def elegir_modalidad(plato):
    datos = CATALOGO_PLATOS[plato]
    if datos["pausado"] or datos["stock"] <= 0:
        return
    lista = [
        Boton(
            f"Comer en el local - S/ {datos['local']:.2f}",
            lambda: elegir_nota(plato, "En local", datos["local"]),
            (195, 240, 205),
        ),
        Boton(
            f"Para llevar - S/ {datos['llevar']:.2f}",
            lambda: elegir_nota(plato, "Para llevar", datos["llevar"]),
            (255, 232, 185),
        ),
        Boton("< Volver al menú", menu_principal, (215, 215, 215)),
    ]
    poner_pantalla(f"{plato}\nElige modalidad", lista, y_inicio=165, separacion=54)


def elegir_nota(plato, modalidad, precio):
    lista = [
        Boton(
            f"Nota: {nota}",
            lambda n=nota: agregar_plato(plato, modalidad, n, precio),
            (210, 232, 255),
        )
        for nota in NOTAS_RAPIDAS
    ]
    lista.append(Boton("< Volver", lambda: elegir_modalidad(plato), (215, 215, 215)))
    poner_pantalla(f"{plato} ({modalidad}) - S/ {precio:.2f}\nEspecificación para cocina", lista, y_inicio=145, separacion=50)


def agregar_plato(plato, modalidad, nota, precio):
    global estado, estado_color
    datos = CATALOGO_PLATOS[plato]
    if datos["pausado"] or datos["stock"] <= 0:
        estado = f"{plato} no está disponible."
        estado_color = (200, 0, 0)
        menu_principal(limpiar=False)
        return

    datos["stock"] -= 1
    carrito.append({"plato": plato, "modalidad": modalidad, "nota": nota, "precio": precio})
    estado = f"Añadido: {plato} [{modalidad}, {nota}] - S/ {precio:.2f}"
    estado_color = (0, 135, 0)
    menu_principal(limpiar=False)


def devolver_carrito():
    for item in carrito:
        CATALOGO_PLATOS[item["plato"]]["stock"] += 1
    carrito.clear()


def seleccionar_propina(monto):
    global propina_actual
    propina_actual = monto
    pantalla_pedido()


def enviar_pedido_cocina():
    global estado, estado_color, propina_actual, ultimo_recibo
    if not carrito:
        estado = "No hay platos en tu pedido."
        estado_color = (180, 90, 0)
        menu_principal(limpiar=False)
        return

    sub = subtotal_carrito()
    prop = propina_actual
    tot = sub + prop
    fecha = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    orden = {
        "id": f"ORD-{len(ordenes_pendientes) + len(ordenes_entregadas) + 1:03d}",
        "fecha": fecha,
        "mesa": mesa_actual(),
        "turno": turno_actual,
        "items": list(carrito),
        "subtotal": sub,
        "propina": prop,
        "total": tot,
        "mesero": None,
    }
    ordenes_pendientes.append(orden)
    ultimo_recibo = orden
    registrar_orden_csv(orden)
    carrito.clear()
    propina_actual = 0.0

    estado = f"Orden {orden['id']} enviada ({orden['mesa']}). Total S/ {tot:.2f}."
    estado_color = (0, 135, 0)
    pantalla_recibo(orden)


def cancelar_pedido():
    global estado, estado_color, propina_actual
    devolver_carrito()
    propina_actual = 0.0
    estado = "Pedido cancelado y stock restaurado."
    estado_color = (150, 90, 0)
    menu_principal(limpiar=False)


def pantalla_pedido():
    global estado
    estado = ""
    if not carrito:
        resumen = "Tu pedido está vacío."
    else:
        lineas = [
            f"- {x['plato']} [{x['modalidad']}, {x['nota']}]: S/ {x['precio']:.2f}"
            for x in carrito[-4:]
        ]
        if len(carrito) > 4:
            lineas.append(f"... y {len(carrito) - 4} más")
        resumen = (
            "\n".join(lineas)
            + f"\nSubtotal: S/ {subtotal_carrito():.2f} | Propina: S/ {propina_actual:.2f} | Total: S/ {total_carrito():.2f}"
        )

    lista = [
        Boton(
            f"Propina: S/ {p:.2f}" + (" (Elegida)" if propina_actual == p else ""),
            lambda monto=p: seleccionar_propina(monto),
            (195, 235, 250) if propina_actual == p else (235, 238, 242),
            activo=len(carrito) > 0,
        )
        for p in PROPINAS_OPCIONES
    ]
    lista.append(Boton("Confirmar y emitir recibo", enviar_pedido_cocina, (165, 235, 180), activo=len(carrito) > 0))
    lista.append(Boton("Cancelar pedido", cancelar_pedido, (255, 200, 200), activo=len(carrito) > 0))
    lista.append(Boton("< Volver", menu_principal, (215, 215, 215)))
    poner_pantalla(f"Pedido - {mesa_actual()}\n{resumen}", lista, y_inicio=270, separacion=46)


def pantalla_recibo(orden):
    global estado
    estado = ""
    lineas_items = [
        f"* {x['plato']} ({x['modalidad']}) - Nota: {x['nota']} - S/ {x['precio']:.2f}"
        for x in orden["items"][-5:]
    ]
    if len(orden["items"]) > 5:
        lineas_items.append(f"... y {len(orden['items']) - 5} ítem(s) más")

    atencion = f"Asignado a: {orden['mesero']}" if orden["mesero"] else "Estado: En cocina / Por asignar"
    cuerpo = (
        f"Recibo {orden['id']} | {orden['mesa']} | Turno {orden['turno']}\n"
        f"Fecha: {orden['fecha']} | {atencion}\n"
        + "\n".join(lineas_items)
        + f"\nSubtotal: S/ {orden['subtotal']:.2f}  |  Propina: S/ {orden['propina']:.2f}  |  TOTAL: S/ {orden['total']:.2f}"
    )
    lista = [Boton("< Volver al menú", menu_principal, (215, 215, 215))]
    poner_pantalla(f"Recibo Virtual\n{cuerpo}", lista, y_inicio=330, separacion=52)


def enviar_comida_a_mesero(mesero):
    global estado, estado_color
    if not ordenes_pendientes:
        estado = "No hay órdenes pendientes por enviar."
        estado_color = (160, 90, 0)
        pantalla_despacho_meseros()
        return

    orden = ordenes_pendientes.pop(0)
    orden["mesero"] = mesero
    ordenes_entregadas.append(orden)
    estado = f"Enviar comida: {orden['id']} ({orden['mesa']}) -> {mesero}"
    estado_color = (0, 125, 45)
    pantalla_despacho_meseros()


def anular_orden_pendiente():
    global estado, estado_color
    if not ordenes_pendientes:
        estado = "No hay órdenes pendientes para anular."
        estado_color = (160, 90, 0)
        pantalla_despacho_meseros()
        return

    orden = ordenes_pendientes.pop(0)
    for item in orden["items"]:
        CATALOGO_PLATOS[item["plato"]]["stock"] += 1
    estado = f"Orden {orden['id']} ({orden['mesa']}) anulada; stock devuelto."
    estado_color = (190, 50, 50)
    pantalla_despacho_meseros()


def pantalla_despacho_meseros():
    global estado
    estado = ""
    if not ordenes_pendientes:
        detalle = "Sin órdenes pendientes."
    else:
        actual = ordenes_pendientes[0]
        resumen_items = ", ".join(f"{x['plato']} [{x['modalidad']}: {x['nota']}]" for x in actual["items"])
        detalle = (
            f"Siguiente: {actual['id']} ({actual['mesa']}) - S/ {actual['total']:.2f} | Cola: {len(ordenes_pendientes)}\n"
            f"{resumen_items}"
        )

    lista = [
        Boton(
            f"Enviar comida -> {m}",
            lambda mes=m: enviar_comida_a_mesero(mes),
            (185, 235, 195),
            activo=len(ordenes_pendientes) > 0,
        )
        for m in MESEROS
    ]
    lista.append(
        Boton(
            "Anular orden pendiente (devuelve stock)",
            anular_orden_pendiente,
            (255, 200, 200),
            activo=len(ordenes_pendientes) > 0,
        )
    )
    lista.append(Boton("< Volver al panel admin", menu_principal, (215, 215, 215)))
    poner_pantalla(f"Despacho a Meseros\n{detalle}", lista, y_inicio=245, separacion=48)


def pantalla_entregadas():
    global estado
    estado = ""
    if not ordenes_entregadas:
        detalle = "Aún no se han enviado órdenes a meseros."
    else:
        lineas = [
            f"- {o['id']} ({o['mesa']}) -> {o['mesero']} (S/ {o['total']:.2f})"
            for o in ordenes_entregadas[-5:]
        ]
        detalle = "\n".join(lineas)

    lista = []
    if ordenes_entregadas:
        lista.append(
            Boton(
                f"Abrir recibo de {ordenes_entregadas[-1]['id']}",
                lambda: pantalla_recibo(ordenes_entregadas[-1]),
                (235, 225, 185),
            )
        )
    lista.append(Boton("< Volver", menu_principal, (215, 215, 215)))
    poner_pantalla(f"Órdenes enviadas\n{detalle}", lista, y_inicio=295, separacion=52)


def alternar_pausa_plato(plato):
    global estado, estado_color
    datos = CATALOGO_PLATOS[plato]
    datos["pausado"] = not datos["pausado"]
    estado_txt = "PAUSADO" if datos["pausado"] else "ACTIVO"
    estado = f"{plato} ahora está {estado_txt}."
    estado_color = (140, 70, 0)
    panel_admin_plato(plato)


def ajustar_stock_plato(plato, delta):
    global estado, estado_color
    datos = CATALOGO_PLATOS[plato]
    datos["stock"] = max(0, datos["stock"] + delta)
    estado = f"Stock de {plato}: {datos['stock']}"
    estado_color = (140, 70, 0)
    panel_admin_plato(plato)


def ajustar_precios_plato(plato, delta):
    global estado, estado_color
    datos = CATALOGO_PLATOS[plato]
    datos["local"] = round(max(1.0, datos["local"] + delta), 2)
    datos["llevar"] = round(max(1.0, datos["llevar"] + delta), 2)
    estado = f"{plato}: Local S/ {datos['local']:.2f} | Llevar S/ {datos['llevar']:.2f}"
    estado_color = (140, 70, 0)
    panel_admin_plato(plato)


def panel_admin_plato(plato):
    datos = CATALOGO_PLATOS[plato]
    estado_str = "PAUSADO" if datos["pausado"] else "ACTIVO"
    info = f"Local: S/ {datos['local']:.2f} | Llevar: S/ {datos['llevar']:.2f} | Stock: {datos['stock']} | {estado_str}"
    lista = [
        Boton("Reponer +5 platos", lambda: ajustar_stock_plato(plato, 5), (185, 235, 195)),
        Boton("Quitar -1 plato", lambda: ajustar_stock_plato(plato, -1), (255, 215, 180)),
        Boton("Subir precios (+S/ 0.50)", lambda: ajustar_precios_plato(plato, 0.50), (255, 235, 160)),
        Boton("Bajar precios (-S/ 0.50)", lambda: ajustar_precios_plato(plato, -0.50), (200, 220, 255)),
        Boton(
            "Activar plato" if datos["pausado"] else "Pausar plato",
            lambda: alternar_pausa_plato(plato),
            (255, 205, 205) if not datos["pausado"] else (190, 240, 205),
        ),
        Boton("< Volver al panel admin", menu_principal, (215, 215, 215)),
    ]
    poner_pantalla(f"Admin: {plato}\n{info}", lista, y_inicio=135, separacion=48)


async def main():
    menu_principal()
    corriendo = True
    while corriendo:
        mouse = pygame.mouse.get_pos()

        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                corriendo = False
            elif evento.type == pygame.KEYDOWN and esperando_clave_admin:
                if evento.key == pygame.K_RETURN:
                    validar_clave_admin()
                elif evento.key == pygame.K_BACKSPACE:
                    clave_escrita = clave_escrita[:-1]
                    render_login_admin()
                elif evento.key == pygame.K_ESCAPE:
                    cancelar_login_admin()
                elif evento.unicode and evento.unicode.isprintable() and len(clave_escrita) < 16:
                    clave_escrita += evento.unicode
                    render_login_admin()
            elif evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                for b in list(botones):
                    if b.activo and b.rect.collidepoint(evento.pos):
                        b.accion()
                        break

        for b in botones:
            b.actualizar(mouse)

        pantalla.fill((244, 246, 249))
        dibujar_texto(titulo, fuente_titulo, (20, 20, 20), 16)
        for b in botones:
            b.dibujar()

        dibujar_texto(estado, fuente_estado, estado_color, ALTO - 92)
        dibujar_texto(
            f"Rol: {modo.upper()} | {mesa_actual()} | Turno: {turno_actual} | Pend: {len(ordenes_pendientes)} | Entreg: {len(ordenes_entregadas)}",
            fuente_chica,
            (110, 110, 110),
            ALTO - 26,
        )

        pygame.display.flip()
        reloj.tick(60)
        await asyncio.sleep(0)


asyncio.run(main())